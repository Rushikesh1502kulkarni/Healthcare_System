<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WelCome Admin</title>
    <link rel="stylesheet" href="Admin main page.css">
</head>
<body>
    <header>
        <div class="brand"><a href="Adminmainpage.php">HealthCare</a></div>

        <nav>
            <ul>
                <li><a href="index.php">Add Doctor</a></li>
                <li><a href="View Doctor.php">View Doctor</a></li>
                <li><a href="View Patient.php">View User</a></li>
                <li><a href="Add Hospital Detail.php">Add Hospital Detail</a></li>
                <li><a href="#">View Hospital Detail</a></li>
                <li><a href="Admin Logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="View Doctor.css">
	<title>View Hospital Detail</title>
	<div class="container">
    <h1>View Hospital Detail</h1>
    <form action="Add Hospital Detail.php" method="POST" class="registartion-form" >
<div class="tbl">
<table border="5">
<tr>
<th>ID</th>
<th>Hospital Name</th>
<th>Address</th>
<th>State</th>
<th>City</th>
<th>Phone No</th>
<th>Pincode</th>
</tr>
</div>
<?php
include("AdminDatabase.php");
error_reporting(0); 
$query = "select * from hospital";
$data = mysqli_query($conn,$query);
$total = mysqli_num_rows($data);

if ($total!=0) 
{
	while($result=mysqli_fetch_assoc($data)) 
	{
		echo "
		<tr>
		<td>".$result['id']."</td>
		<td>".$result['hospital_name']."</td>
		<td>".$result['address']."</td>
		<td>".$result['state']."</td>
		<td>".$result['city']."</td>
		<td>".$result['phone_no']."</td>
		<td>".$result['pincode']."</td>
		</tr>
		";
		
	}
}
else
{
	echo "No record Found";
}
?>
</table>
</form>
</div>
</head>
<body>
</body>
</html>