<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WelCome Admin</title>
    <link rel="stylesheet" href="Admin main page.css">
</head>
<body>
    <header>
        <div class="brand"><a href="Adminmainpage.php">HealthCare</a></div>

        <nav>
            <ul>
                <li><a href="index.php">Add Doctor</a></li>
                <li><a href="View Doctor.php">View Doctor</a></li>
                <li><a href="#">View User</a></li>
                <li><a href="Add Hospital Detail.php">Add Hospital Detail</a></li>
                <li><a href="#">View Hospital Detail</a></li>
                <li><a href="Admin Logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="View Doctor.css">
  <title>View Patient</title>
  <div class="container">
    <h1>View Patient</h1>
<form action="View Patient.php" method="POST" class="registartion-form" >
<div class="tbl">
<table border="5">
<tr>
<th>ID</th>
<th>Email</th>
<th>Patient name</th>
<th>Action</th>
</tr>
</div>
<?php
include("AdminDatabase.php");
error_reporting(0); 
$query = "select * from users";
$data = mysqli_query($conn,$query);
$total = mysqli_num_rows($data);

if ($total!=0) 
{
  while($result=mysqli_fetch_assoc($data)) 
  {
    echo "
    <tr>
    <td>".$result['user_id']."</td>
    <td>".$result['email']."</td>
    <td>".$result['fname']."</td>
    <td><a href = 'Delete.php?rn=$result[user_id]'> Delete</td>
    </tr>
    ";
    
  }
}
else
{
?>
</table>
<h2 align="center"> No record Found </h2>
</p>
<?php
}
?>
</form>
</div>
</head>
<body>
</body>
</html>