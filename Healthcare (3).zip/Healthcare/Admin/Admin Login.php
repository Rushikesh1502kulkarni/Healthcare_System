<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
  <div class="container">
  <div class="wrapper">
  <header>Admin Login</header>
<?php
       if (isset($_POST["login"])) {
           $name = $_POST["name"];
           $password = $_POST["password"];
           require_once "AdminDatabase.php";
           $sql ="SELECT * FROM admin WHERE name = '$name' AND password = '$password'";
           $result = mysqli_query($conn, $sql);
           $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
           if($user){  
                echo "<div class='alert alert-danger'>Password match</div>";
                header("Location: Adminmainpage.php");  
              }
              else{
                echo "<script> alert('Please Check Your Name or password Something is wrong')</script>";
                //echo"<div class='alert alert-danger'>Please Your Email or password Something is wrong  </div>";
              }
         }      
?>
    <form action="Admin Login.php" method="POST">
      <div class="field email">
        <div class="input-area">
          <input type="text" placeholder="Name" name="name" required>
          <i class="icon fas fa-envelope"></i>
          <i class="error error-icon fas fa-exclamation-circle"></i>
        </div>
        <div class="error error-txt">Name can't be blank</div>
      </div>
      <div class="field password">
        <div class="input-area">
          <input type="password" placeholder="Password" name="password" required>
          <i class="icon fas fa-lock"></i>
          <i class="error error-icon fas fa-exclamation-circle"></i>
        </div>
        <div class="error error-txt">Password can't be blank</div>
      </div>
      <input type="submit" value="Login" name="login">
    </form>
  </body>
</html>