<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WelCome Admin</title>
    <link rel="stylesheet" href="Admin main page.css">
</head>
<body>
    <header>
        <div class="brand"><a href="Adminmainpage.php">HealthCare</a></div>

        <nav>
            <ul>
                <li><a href="index.php">Add Doctor</a></li>
                <li><a href="#">View Doctor</a></li>
                <li><a href="View Patient.php">View User</a></li>
                <li><a href="Add Hospital Detail.php">Add Hospital Detail</a></li>
                <li><a href="View Hospital Detail.php">View Hospital Detail</a></li>
                <li><a href="Admin Logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="View Doctor.css">
	<title>View Doctor</title>
	<div class="container">
    <h1>View Doctor</h1>
    <form action="Add Doctor.php" method="POST" class="registartion-form" >
<div class="tbl">
<table border="5">
<tr>
<th>ID</th>
<th>Doctor name</th>
<th>Email</th>
<th>Doctor type</th>
<th>Qualification</th>
<th>Action</th>
</tr>
</div>
<?php
include("AdminDatabase.php");
error_reporting(0); 
$query = "select * from doctors";
$data = mysqli_query($conn,$query);
$total = mysqli_num_rows($data);

if ($total!=0) 
{
	while($result=mysqli_fetch_assoc($data)) 
	{
		echo "
		<tr>
		<td>".$result['doctor_id']."</td>
		<td>".$result['fname']."</td>
		<td>".$result['email']."</td>
		<td>".$result['doctor_type']."</td>
		<td>".$result['qualification']."</td>
		<td><a href = 'Delete1.php?rn=$result[doctor_id]'> Delete</td>
		</tr>
		";
		
	}
}
else
{
?>
</table>
<h2 align="center"> No record Found </h2>
</p>
<?php
}
?>
</form>
</div>
</head>
<body>
</body>
</html>