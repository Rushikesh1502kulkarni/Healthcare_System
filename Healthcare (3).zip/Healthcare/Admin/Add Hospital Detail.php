<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WelCome Admin</title>
    <link rel="stylesheet" href="Admin main page.css">
</head>
<body>
    <header>
        <div class="brand"><a href="Adminmainpage.php">HealthCare</a></div>

        <nav>
            <ul>
                <li><a href="index.php">Add Doctor</a></li>
                <li><a href="View Doctor.php">View Doctor</a></li>
                <li><a href="View Patient.php">View User</a></li>
                <li><a href="#">Add Hospital Detail</a></li>
                <li><a href="View Hospital Detail.php">View Hospital Detail</a></li>
                <li><a href="Admin Logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="Add Doctor.css">
  <title>Add Hospital Detail</title>
  <div class="container">
    <h1>Add Hospital Detail</h1>
     <?php
    if (isset($_POST["Add"])) {
     $hospital_name = $_POST["hospital_name"];
     $phone_no = $_POST["phone_no"];
     $address = $_POST["address"];
     $state = $_POST["state"];
     $city = $_POST["city"];
     $pincode = $_POST["pincode"];

     require_once "AdminDatabase.php";
     $sql = "INSERT INTO  hospital (hospital_name, phone_no, address, state, city, pincode) VALUES (?, ?, ?, ?, ?, ?)"; 
     $stmt = mysqli_stmt_init($conn);
     $prepareStmt = mysqli_stmt_prepare($stmt,$sql);
     if ($prepareStmt) {
        mysqli_stmt_bind_param($stmt,"sisssi", $hospital_name, $phone_no, $address, $state, $city, $pincode);
        mysqli_stmt_execute($stmt);
        echo "<script> alert('Hospital Added successfully')</script>";
        //echo "<div class ='alert alert-success'>You registered successfully.</div>";
        //header("Location: Add Doctor.php");
      }else{
        die("something went wrong");
      }
    }
  ?>
  <form action="Add Hospital Detail.php" method="POST" class="registartion-form" >
    <table>
      <tr>
        <td><label for="hospital_name">Hospital Name: </label></td>
        <td><input type="text" name="hospital_name"></td>
      </tr>
      <tr>
        <td><label for="phone_no">Phone No:</label></td>
        <td><input type="integer" name="phone_no"></td>
      </tr>
      <tr>
        <td><label for="address">Address: </label></td>
        <td><input type="text" name="address"></td>
      </tr>
            <tr>
        <td><label for="state">State: </label></td>
        <td><input type="text" name="state"></td>
      </tr>
      <tr>
        <td><label for="city">City: </label></td>
        <td><input type="text" name="city"></td>
      </tr>
      <tr>
        <td><label for="pincode">Pincode: </label></td>
        <td><input type="integer" name="pincode"></td>
      </tr>
      <tr>
        <td colspan="2"><input type="submit" class="submit" value="Add" name="Add" /></td>
      </tr>
    </table>
  </form>
</div>
</head>
<body>
</body>
</html>