<?php
include("AdminDatabase.php");
error_reporting(0);

$id = $_GET['rn'];
$query = "DELETE FROM users WHERE user_id = '$id'";

$data = mysqli_query($conn,$query);

if ($data)
{
	echo "<script> alert('Record Deleted From Database')</script>";
}
else
{
	echo "<script> alert('Failed to Deleted From Database')</script>";
}
header("Location: View Patient.php");
?>
