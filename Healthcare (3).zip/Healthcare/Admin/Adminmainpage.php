<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WelCome Admin</title>
    <link rel="stylesheet" href="Admin main page.css">
</head>
<body>
    <header>
        <div class="brand"><a href="Adminmainpage.php" >HealthCare</a></div>

        <nav>
            <ul>
                <li><a href="index.php">Add Doctor</a></li>
                <li><a href="View Doctor.php">View Doctor</a></li>
                <li><a href="View Patient.php">View User</a></li>
                <li><a href="Add Hospital Detail.php">Add Hospital Detail</a></li>
                <li><a href="View Hospital Detail.php">View Hospital Detail</a></li>
                <li><a href="Admin Logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
</body>
</html>