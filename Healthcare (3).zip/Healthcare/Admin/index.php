
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WelCome Admin</title>
    <link rel="stylesheet" href="Admin main page.css">
</head>
<body>
    <header>
        <div class="brand"><a href="Adminmainpage.php">HealthCare</a></div>
        <nav>
            <ul>
                <li><a href="#">Add Doctor</a></li>
                <li><a href="View Doctor.php">View Doctor</a></li>
                <li><a href="View Patient.php">View User</a></li>
                <li><a href="Add Hospital Detail.php">Add Hospital Detail</a></li>
                <li><a href="View Hospital Detail.php">View Hospital Detail</a></li>
                <li><a href="Admin Logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
</body>
</html>

<?php include_once "header.php"; ?>
<body>
  <div class="wrapper">
    <section class="form signup">
      <h1> Add Doctor </h1>
      <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>
        <div class="name-details">
          <div class="field input">
            <label>First Name</label>
            <input type="text" name="fname" placeholder="First name" required>
          </div>
          <div class="field input">
            <label>Last Name</label>
            <input type="text" name="lname" placeholder="Last name" required>
          </div>
        </div>
        <div class="field input">
          <label>Email Address</label>
          <input type="text" name="email" placeholder="Enter your email" required>
        </div>
        <div class="field input">
          <label>Password</label>
          <input type="password" name="password" placeholder="Enter new password" required>
          <i class="fas fa-eye"></i>
        </div>
        <div class="field input">
        <label for="doctor_type">Doctor Type:</label>
          <select name="doctor_type" id="doctor_type">
            <option value=""> Select </option>
            <option value="Heart">Heart</option>
            <option value="Bone">Bone</option>
            <option value="Lungs">Lungs</option>
            <option value="Kidney">Kidney</option>
          </select>
        </div>
          <div class="field input">
          <label>Qualification</label>
          <input type="text" name="qualification" placeholder=" Qualification" required>
        </div>
        <div class="field image">
          <label>Select Image</label>
          <input type="file" name="image" accept="image/x-png,image/gif,image/jpeg,image/jpg" required>
        </div>
        <div class="field button">
          <input type="submit" name="submit" value="ADD">
        </div>
      </form>
    </section>
  </div>

  <script src="javascript/pass-show-hide.js"></script>
  <script src="javascript/signup.js"></script>

</body>
</html>
