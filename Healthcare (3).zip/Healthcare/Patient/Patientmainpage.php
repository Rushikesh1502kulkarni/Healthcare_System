<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare</title>
    <link rel="stylesheet" href="Patient main page.css">
</head>
<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<body>
    <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
          </div>
        <div class="brand"><a href="Patientmainpage.php" >HealthCare</a></div>

        <nav>
            <ul>
                <li><a href="Update.php?fn=<?php echo $row['fname'];?> & ln=<?php echo $row['lname'];?> & em=<?php echo         
                $row['email'];?> & pass=<?php echo 
                $row['password'];?>">Update Detail</a></li>
                <li><a href="View Hospital Detail.php">View Hospitals</a></li>
                <li><a href="users.php">ChatBox</a></li>
                <li><a href="php/logout.php?logout_id=<?php echo $row['unique_id'];  ?>">Logout</a></li>
            </ul>
        </nav>
    </header>
</body>
</html>