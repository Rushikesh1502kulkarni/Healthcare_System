<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WelCome Admin</title>
    <link rel="stylesheet" href="Patient main page.css">
    <link rel="stylesheet" href="Update.css">
</head>
<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<body>
    <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
        </div>
        <div class="brand"><a href="Patientmainpage.php">HealthCare</a></div>

        <nav>
            <ul>
                <li><a href="Update.php?fn=<?php echo $row['fname'];?> & ln=<?php echo $row['lname'];?> & em=<?php echo 
                $row['email'];?> & pass=<?php echo 
                $row['password'];?>">Update Detail</a></li>
                <li><a href="View Hospital Detail.php">View Hospitals</a></li>
                <li><a href="users.php">ChatBox</a></li>
                <li><a href="php/logout.php?logout_id=<?php echo $row['unique_id'];  ?>">Logout</a></li>
            </ul>
        </nav>
    </header>

<?php
include_once "php/config.php";
error_reporting(0);
$fn = $_GET['fn'];
$ln = $_GET['ln'];
$em = $_GET['em'];
$pass = $_GET['pass'];
?>

   <head>
  <div class="container">
    <h1>Update Detail</h1>
  <form action="Update.php" method="GET" class="registartion-form" >
    <table>
      <tr>
        <td><label>First Name :</label></td> 
        <td><input type="text" name="fname" value="<?php echo "$fn" ?>" required></td>
      </tr>
      <tr>
        <td><label>Last Name :</label></td>
        <td><input type="text" name="lname" value="<?php echo "$ln" ?>" required></td>
      </tr>
      <tr>
        <td><label>Email Address : </label></td>
        <td><input type="text" name="email" value="<?php echo "$em" ?>" required></td>
      </tr>
            <tr>
        <td><label> New Password : </label></td>
        <td><input type="password" name="password" value="" required></td>
      </tr>
      <tr>
        <td colspan="2"><input type="submit" class="submit" value="Update" name="submit" /></td>
      </tr>
    </table>
  </form>
</div>
</head>
</html>

<?php

if ($_GET['submit']) {
  $fname = $_GET['fname'];
  $lname = $_GET['lname'];
  $email = $_GET['email'];
  $password = $_GET['password'];

  $encrypt_pass = md5($password);

  $query = "UPDATE users SET fname ='$fname', lname = '$lname', email = '$email', password = '$encrypt_pass'";

  $data = mysqli_query($conn,$query);

  if ($data) {
    echo '<script> alert("Updated Successfully") </script>';
  }
  else
  {
    echo "Failed to Update ";
  }
}
?>