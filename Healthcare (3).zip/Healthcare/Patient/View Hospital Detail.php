<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare System</title>
    <link rel="stylesheet" href="Patient main page.css">
</head>
<body>
	<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
    <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
          </div>
        <div class="brand"><a href="Adminmainpage.php">HealthCare</a></div>

        <nav>
            <ul>
                <li><a href="Update.php">Update Detail</a></li>
                <li><a href="#">View Hospitals</a></li>
                <li><a href="users.php">ChatBox</a></li>
                <li><a href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>">Logout</a></li>
            </ul>
        </nav>
    </header>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="View Hospital Detail.css">
	<title>View Hospital Detail</title>
	<div class="container">
    <h1>View Hospital Detail</h1>
    <form action="Add Hospital Detail.php" method="POST" class="registartion-form" >
<div class="tbl">
<table border="5">
<tr>
<th>ID</th>
<th>Hospital Name</th>
<th>Address</th>
<th>State</th>
<th>City</th>
<th>Phone No</th>
<th>Pincode</th>
</tr>
</div>
<?php
include_once "php/config.php";
error_reporting(0); 
$query = "select * from hospital";
$data = mysqli_query($conn,$query);
$total = mysqli_num_rows($data);

if ($total!=0) 
{
	while($result=mysqli_fetch_assoc($data)) 
	{
		echo "
		<tr>
		<td>".$result['id']."</td>
		<td>".$result['hospital_name']."</td>
		<td>".$result['address']."</td>
		<td>".$result['state']."</td>
		<td>".$result['city']."</td>
		<td>".$result['phone_no']."</td>
		<td>".$result['pincode']."</td>
		</tr>
		";
		
	}
}
else
{
	echo "No record Found";
}
?>
</table>
</form>
</div>
</head>
<body>
</body>
</html>