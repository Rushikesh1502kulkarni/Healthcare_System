<!DOCTYPE html>  
<html>  
<head>  
	<title>Login Page</title>
<style>  
body{  
background-color: lightblue;  
}  
#image {  
display: block;  
margin-left: auto;  
margin-right: auto;  
border: 8px ridge blue;  
padding: 5px;  

}  

</style>  
</head>  
<body>  
<img src = "Healthcare System.jpg" id ="image" width="600" height="260">  
</body>  
</html>  


<!DOCTYPE html> 
<html> 
    <head> 
      
        <!-- CSS style to put div side by side -->
        <style type="text/css"> 
        .container {
            width:600px;
            height:190px;
            background-color:;
            padding-top:10px;
            padding-left:20px;
            padding-right:15px;
        }

        #st-box {
            float:left;
            width:180px;
            height:160px;
            background-color:white;
            border:solid black;
        }
        #nd-box {
            float:left;
            width:180px;
            height:160px;
            background-color:white; 
            border:solid black;
            margin-left:20px;
        }
        #rd-box {
            float:right;
            width:180px;
            height:160px;
            background-color:white;
            border:solid black;
        }
        h1 {
            color:indianred;
        }
        </style> 
    </head> 
      
    <body>
          <center>
          	<h1> Login </h1>
        <div class="container">
            <div id="st-box">
            	<a href="Admin\Admin Login.php" > 
                <img src= "admin.png
                "style="width:180px; height:160px;">

            </div>
              
            <div id="nd-box">
            	<a href="Doctor\login.php" > 
            	<img src= "Doctor.jpg
                "style="width:180px; height:160px;"> 
            </div>
              
            <div id="rd-box">
            	<a href="Patient\login.php" > 
                <img src= "Patient.png
                "style="width:180px; height:160px;">
            </div>
        </div>
        </center>
    </body>
</html> 
